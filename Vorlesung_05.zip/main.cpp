#include "Optimization.h"
#include <iostream>
#include <chrono>

constexpr int nRuns = 5;
constexpr double original = 2000.0; // [ms], hier einfügen

int main()
{
    using clock = std::chrono::high_resolution_clock;
    double total = 0.0;
    for (int i = 0; i < nRuns; i++) {
        std::cerr << "Run " << i << ": ";
        auto t1 = clock::now();
        run();
        auto t2 = clock::now();
        std::chrono::duration<double, std::milli> delta = t2 - t1;
        double milliseconds = delta.count();
        std::cerr << milliseconds << "ms" << std::endl;
        total += milliseconds;
    }
    double average = total / nRuns;

    double speedup = original / average;
    std::cout
        << original << "ms -> " << average << "ms" << std::endl
        << "Speedup: " << speedup << std::endl;
}
