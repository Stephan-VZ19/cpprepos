#pragma once
#include <memory>
#include <iostream>

class RGBImage {
    size_t m_size;
    int m_width, m_height;
    std::unique_ptr<uint8_t[]> m_data;

public:
    RGBImage() {}

    RGBImage(int width, int height)
        : m_size(3 * width * height)
        , m_width(width)
        , m_height(height)
        , m_data(std::make_unique<uint8_t[]>(m_size))
    {}

    RGBImage(const uint8_t data[], int width, int height)
        : RGBImage(width, height)
    {
        std::copy(data, data+m_size, m_data.get());
    }

    RGBImage(std::unique_ptr<uint8_t[]>&& data, int width, int height)
        : m_size(3 * width * height)
        , m_width(width)
        , m_height(height)
        , m_data(std::move(data))
    {}

    RGBImage(const RGBImage& img)
        : RGBImage(img.m_width, img.m_height)
    {
        std::copy(img.m_data.get(), img.m_data.get()+img.m_size, m_data.get());
    }

    RGBImage(RGBImage&& img)
        : m_size(std::exchange(img.m_size, 0))
        , m_width(std::exchange(img.m_width, 0))
        , m_height(std::exchange(img.m_height, 0))
        , m_data(std::exchange(img.m_data, nullptr))
    {}

    RGBImage& operator=(const RGBImage& other) {
        if (&other != this) {
            m_width = other.m_width;
            m_height = other.m_height;
            m_size = other.m_size;
            m_data = std::make_unique<uint8_t[]>(m_size);
            std::copy(other.m_data.get(), other.m_data.get() + m_size, m_data.get());
        }
        return *this;
    }

    RGBImage& operator=(RGBImage&& other) {
        if (&other != this) {
            std::swap(m_width, other.m_width);
            std::swap(m_height, other.m_height);
            std::swap(m_size, other.m_size);
            std::swap(m_data, other.m_data);
        }
        return *this;
    }

    int getWidth() const { return m_width; }
    int getHeight() const { return m_height; }

    bool isWhite(int x, int y) const {
        int i = 3 * ((y * m_width) + x);
        return (m_data[i] == 255) &&
               (m_data[i+1] == 255) &&
               (m_data[i+2] == 255);
    }

    static RGBImage makeWhiteImage(int width, int height);

    friend std::ostream& operator<<(std::ostream& os, const RGBImage& img) {
        return os << '(' << img.m_width << 'x' << img.m_height << ')' << " data[" << img.m_size << ']' << std::endl;
    }
};
