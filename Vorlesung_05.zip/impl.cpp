#include <iostream>
#include <vector>
#include <memory>
#include <cassert>

#include "Optimization.h"
#include "Image.h"

RGBImage RGBImage::makeWhiteImage(int width, int height) {
    size_t size = 3 * width * height;
    auto data = std::make_unique<uint8_t[]>(size);
    for (size_t i = 0; i < size; i++) {
        data[i] = 255;
    }
    return RGBImage(data.get(), width, height);
}

void check(RGBImage img) {
    assert(img.getWidth() == params::width);
    assert(img.getHeight() == params::height);
    assert(img.isWhite(0, 0));
    assert(img.isWhite(params::width-1, params::height-1));
}

void run() {
    std::vector<RGBImage> gallery;
    for (int i = 0; i < params::numIterations; i++) {
        const RGBImage img = RGBImage::makeWhiteImage(params::width, params::height);
        gallery.push_back(img);
    }

    assert(gallery.size() == params::numIterations);
    for (const RGBImage img : gallery) {
        check(img);
    }
}
