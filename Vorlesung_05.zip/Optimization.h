#pragma once

namespace params {
    constexpr int numIterations = 200;
    constexpr int width = 1500;
    constexpr int height = 1000;
}

void run();
